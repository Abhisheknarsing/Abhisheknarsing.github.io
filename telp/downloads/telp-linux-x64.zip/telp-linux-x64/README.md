# telp - తెలుగు ప్రోగ్రామింగ్ భాష 🇮🇳

**Telugu Programming Language** - Write code in Telugu (తెలుగు), transpiles to JavaScript, and executes via Node.js.

## Features

- ✅ Write programs in Telugu script
- ✅ Variables, arithmetic, and string operations
- ✅ Conditional statements (if/else/elif)
- ✅ Loops (while and for)
- ✅ Functions with recursion support
- ✅ Arrays and indexing
- ✅ Interactive REPL
- ✅ Transpile to JavaScript
- ✅ Cross-platform binaries (Windows/Linux/macOS)
- ✅ Bundled Node.js support

## Quick Start

```bash
# Run a Telugu program
telp hello.tl

# Or explicitly
telp run examples/hello.tl

# Start interactive REPL
telp repl

# Show help
telp help
```

## Installation

### Download Pre-built Binaries

Download the appropriate binary for your system:

| Platform | Binary |
|----------|--------|
| Windows (x64) | `telp-windows-amd64.exe` |
| Windows (ARM) | `telp-windows-arm64.exe` |
| Linux (x64) | `telp-linux-amd64` |
| Linux (ARM) | `telp-linux-arm64` |
| macOS (Intel) | `telp-darwin-amd64` |
| macOS (Apple Silicon) | `telp-darwin-arm64` |

### Build from Source

```bash
# Clone the repository
git clone https://github.com/user/tp-lang.git
cd tp-lang

# Build for current OS
go build -o telp .

# Or build for all platforms
./build.sh        # Linux/macOS
build.bat         # Windows
```

## Node.js Requirement

telp requires Node.js to execute programs. It looks for Node.js in this order:

1. **System PATH** - Uses the `node` command if available
2. **Bundled** - Uses `./core/node/bin/node.exe` (Windows) or `./core/node/bin/node` (Linux/macOS)

### Option 1: Install Node.js System-wide (Recommended)
Download from [nodejs.org](https://nodejs.org/) and install.

### Option 2: Bundle Node.js with telp
Place the Node.js binary in the `core/node/bin/` directory:
- Windows: `core/node/bin/node.exe`
- Linux/macOS: `core/node/bin/node`

## Telugu Keywords

| Telugu | English | Description |
|--------|---------|-------------|
| `మాట్లాడు` | print | Output to console |
| `సృష్టించు` | let/var | Variable declaration |
| `ఉంటే` | if | Conditional if |
| `లేకపోతే` | else | Conditional else |
| `అయితే` | elif | Else if |
| `చేయి` | while | While loop |
| `కొరకు` | for | For loop |
| `పని` | function | Function definition |
| `చల్లు` | return | Return from function |
| `నిజం` | true | Boolean true |
| `అబద్ధం` | false | Boolean false |
| `శూన్యం` | null | Null value |
| `మరియు` | and | Logical AND |
| `లేదా` | or | Logical OR |
| `కాదు` | not | Logical NOT |
| `విరమించు` | break | Break loop |
| `కొనసాగించు` | continue | Continue loop |

## Examples

### Hello World

```telugu
# hello.tl
మాట్లాడు("నమస్కారం ప్రపంచం!")
```

```bash
telp hello.tl
# Output: నమస్కారం ప్రపంచం!
```

### Variables

```telugu
సృష్టించు పేరు = "రామ్"
సృష్టించు వయస్సు = 25
మాట్లాడు(పేరు)
మాట్లాడు(వయస్సు)
```

### Conditionals

```telugu
సృష్టించు సంఖ్య = 10

ఉంటే (సంఖ్య > 5) {
    మాట్లాడు("పెద్దది")
} లేకపోతే {
    మాట్లాడు("చిన్నది")
}
```

### Loops

```telugu
సృష్టించు i = 1
చేయి (i <= 5) {
    మాట్లాడు(i)
    i = i + 1
}
```

### Functions

```telugu
పని జోడించు(a, b) {
    చల్లు a + b
}

సృష్టించు ఫలితం = జోడించు(3, 4)
మాట్లాడు(ఫలితం)  # Output: 7
```

### Recursion (Factorial)

```telugu
పని క్రమగుణితం(n) {
    ఉంటే (n <= 1) {
        చల్లు 1
    }
    చల్లు n * క్రమగుణితం(n - 1)
}

మాట్లాడు(క్రమగుణితం(5))  # Output: 120
```

## CLI Commands

```
telp <file.tl>           Run a Telugu program directly
telp run <file.tl>       Run a Telugu program
telp transpile <file.tl> Output JavaScript code (without running)
telp repl                Start interactive REPL
telp help                Show help message
telp version             Show version
```

## Project Structure

```
tp-lang/
├── main.go                 # CLI entry point
├── build.sh                # Linux/macOS build script
├── build.bat               # Windows build script
├── core/
│   └── node/               # Bundled Node.js directory
├── pkg/
│   ├── keywords/           # Telugu keyword definitions
│   ├── lexer/              # Tokenizer (Unicode support)
│   ├── parser/             # Parser and AST
│   ├── generator/          # JavaScript code generator
│   └── runtime/            # Node.js executor
├── examples/               # Example programs
│   ├── hello.tl
│   ├── variables.tl
│   ├── conditions.tl
│   ├── loops.tl
│   ├── functions.tl
│   └── fibonacci.tl
└── build/                  # Built binaries
```

## How It Works

```
Telugu Source → Lexer → Parser → AST → JavaScript Generator → Node.js
     (.tl)                                     (.js)          (execute)
```

1. **Lexer**: Tokenizes Telugu source code with full Unicode support
2. **Parser**: Builds an Abstract Syntax Tree (AST) using recursive descent parsing
3. **Generator**: Transpiles the AST to JavaScript code
4. **Runtime**: Executes the JavaScript via Node.js

## License

MIT License

## Contributing

Contributions are welcome! Feel free to submit issues and pull requests.

---

Made with ❤️ for Telugu speakers learning to code.

**తెలుగులో కోడ్ చేయండి!** (Code in Telugu!)
