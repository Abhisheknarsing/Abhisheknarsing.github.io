# Merge Conflict — Fun Friday

A host-operated game for a team video call or an in-person screen share.

Open `dist/index.html` in a browser, or serve `dist` with `python3 -m http.server 4173 --directory dist` and visit http://localhost:4173.

1. Split into 2–6 teams and enter team names.
2. Choose the Friday Mix or one of three puzzle categories.
3. Choose 6 or 12 rounds and a 30, 45, or 60-second timer.
4. Share the game window. Start each timer when everyone is ready.
5. Teams call their name, then answer aloud or in meeting chat.
6. Reveal the answer and award the winning team 100 points. Tap an awarded team to undo, or another team to move the award.
7. Advance to final scores. Ties share the win.

Only the host needs the game. There is no network multiplayer or player login. Session progress is saved in this browser's local storage; refreshing pauses the game and offers Resume. The optional web fonts need internet; the game uses system fallbacks without them.

Keyboard: Space toggles the timer, R reveals an answer, Right Arrow advances/skips, F toggles fullscreen. Inputs and open instructions suppress shortcuts.

The 36 puzzles are shuffled without repeats within a session. The mix has equal numbers of emoji puzzles, tech riddles and JavaScript bug hunts. New sessions can reuse puzzles.

Checks: `node checks/smoke.cjs`.
