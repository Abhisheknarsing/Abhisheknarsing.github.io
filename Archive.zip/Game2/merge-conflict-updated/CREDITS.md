# Asset credits

Logo symbols sourced from Simple Icons: https://simpleicons.org and https://github.com/simple-icons/simple-icons. Downloaded from the simple-icons npm distribution via jsDelivr on 16 October 2026. Brand marks belong to their respective owners. The quiz uses monochrome symbol variants for recognition.

Dev Taboo’s original 22 cards and additional emoji puzzles were adapted from the supplied ship-it-friday.html. 30 additional Taboo cards were added.
