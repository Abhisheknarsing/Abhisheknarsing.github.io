const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
let now=10000;let callback;
const doc={querySelector(){return {textContent:'',classList:{toggle(){}}}},addEventListener(){},getElementById(){return {innerHTML:''}}};
const context=vm.createContext({console,Date:{now:()=>now},localStorage:{getItem:()=>null,setItem(){}},document:doc,window:{addEventListener(){},scrollTo(){}},setInterval(fn){callback=fn;return 1},clearInterval(){},setTimeout(){},clearTimeout(){},matchMedia:()=>({matches:true})});
for(const file of ['questions.js','taboo.js','app.js'])vm.runInContext(fs.readFileSync('dist/'+file,'utf8').replace(/render\(\);\s*$/,''),context);
function run(s){return vm.runInContext(s,context)}
run(`render=()=>{stopTick();if(screen==='game'&&game.running)runTick()};toast=()=>{};
if(MODES.mix||MODES.bug)throw Error('Removed modes remain');
for(const mode of ['emoji','riddle','logo'])for(const rounds of [6,12]){
 config={teams:['A','B'],mode,rounds,seconds:45};start();
 if(game.deck.length!==rounds||new Set(game.deck.map(q=>q.clue||q.image||q.prompt)).size!==rounds)throw Error('Deck not unique');
 reveal();award(0);award(1);if(game.scores[0]!==0||game.scores[1]!==100)throw Error('Score move');award(1);if(game.scores[1]!==0)throw Error('Undo');
 for(let i=0;i<rounds;i++)next();if(!game.finished)throw Error('No finish');
}
for(let count=2;count<=6;count++)for(const rounds of [6,12]){
 config={teams:Array.from({length:count},(_,i)=>'Team '+i),mode:'taboo',rounds,seconds:45};start();
 const expected=count*(rounds===6?1:2);if(game.deck.length!==expected)throw Error('Unequal turns');
 for(let turn=0;turn<expected;turn++){
  if(activeTeam()!==turn%count)throw Error('Wrong team');
  clueWindow={closed:false,document:{getElementById:()=>null},close(){this.closed=true}};updateClues=()=>{};
  beginTaboo();if(game.remaining!==60||!game.running)throw Error('No start');
  tabooCard('got');tabooCard('skipped');tabooCard('buzzed');
  const team=activeTeam(),score=game.scores[team];undoTaboo();if(game.taboo.buzzed!==0||game.scores[team]!==score)throw Error('Buzz undo');
  undoTaboo();undoTaboo();if(game.taboo.got!==0||game.scores[team]!==score-100)throw Error('Scored card undo');
  toggleTaboo();tabooCard('got');endTaboo();nextTaboo();
 }
 if(!game.finished||game.scores.some(n=>n!==100*(rounds===6?1:2)))throw Error('Taboo scoring or finish');
}
config={teams:['A','B'],mode:'taboo',rounds:6,seconds:45};start();
clueWindow={closed:false,document:{getElementById:()=>null},close(){this.closed=true}};
beginTaboo();game.cardPos=game.cards.length-1;tabooCard('got');if(game.taboo.phase!=='done')throw Error('Deck exhaustion');nextTaboo();if(game.cardPos!==0)throw Error('Deck refill');
`);
assert.equal(run('TABOO_CARDS.length'),52);assert.equal(run("QUESTIONS.filter(q=>q.type==='logo').length"),21);
run(`config={teams:['A','B'],mode:'logo',rounds:6,seconds:45};start();game.running=true;runTick();`);
const initial=run('deadline');now+=12000;run('runTick()');assert.equal(run('deadline'),initial,'Rerenders must not extend timer');callback();assert.equal(run('game.remaining'),33);
console.log('PASS: 6 quiz decks; 10 equal-turn Taboo configurations; score correction, undo, deck exhaustion/refill, final scores, 52 Taboo cards, 21 logos; stable timer deadline.');
