# Merge Conflict — updated Fun Friday game

Double-click merge-conflict.html to open the game in Chrome, Edge, Firefox, or Safari. No server, login, or internet connection is required. Logo images, game content, styling and scripts are embedded in the single HTML file.

## Games

Developer games: Dev Taboo (52 cards), Emoji Decode (23 puzzles) and Name That Tech (12 clues). Regular games: Logo Quiz (21 monochrome brand symbols). Friday Mix and Spot the Bug have been removed.

Set up 2–6 teams. Quiz categories use 6 or 12 shuffled questions and a 30, 45 or 60-second timer. Reveal the answer and award 100 points to the team. Tap the winning team again to undo, or tap a different team to move the award.

## Dev Taboo

The host gives clues and the active team guesses aloud. Use “Open host cards” to open a separate private window. Allow pop-ups for this local file if the browser asks. Share ONLY the main game window or tab in your meeting, never the entire desktop or clue window. Cards and banned words never appear on the shared stage.

Pick one or two turns per team. Every team gets equal 60-second turns. Got it = +100, skip = 0, buzz for saying a banned word = 0. Undo reverses the last card and pauses the timer. Continue to resume. End turn allows an early finish. A closed clue window pauses the timer; reopen it to continue.

Keyboard in Taboo: G = got it, S = skip, B = buzz, U = undo, Space = start/pause. These work in the clue window too. In quizzes, Space = timer, R = reveal, Right Arrow = next/skip. F toggles fullscreen in the main window.

Progress is saved in this browser when local storage is available. On refresh, use Resume. Taboo resumes paused and requires reopening the clue window. Logo rounds do not reveal the brand name until Reveal; the first-letter hint is optional. Some logos are symbol variants without their usual accompanying wordmarks.

New sessions can reuse puzzles. Taboo cards do not repeat until the 52-card deck is exhausted, then the next turn starts a new shuffled deck.

Original Taboo cards and extra emoji puzzles came from the supplied ship-it-friday.html. The original file was not modified. See CREDITS.md for logo attribution.
