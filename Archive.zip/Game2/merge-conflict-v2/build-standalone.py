from pathlib import Path
root=Path(__file__).parent
html=(root/'dist/index.html').read_text()
css=(root/'dist/style.css').read_text()
css='\n'.join(line for line in css.splitlines() if not line.startswith('@import'))
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
for name in ['questions.js','taboo.js','app.js']:
 js=(root/'dist'/name).read_text().replace('</script','<\\/script')
 html=html.replace('<script src="'+name+'"></script>','<script>'+js+'</script>')
assert 'src="app.js"' not in html and 'src="questions.js"' not in html and 'src="taboo.js"' not in html
assert 'Spot the Bug' not in html and 'The Friday Mix' not in html
for path in [root/'dist/merge-conflict.html',root.parent/'merge-conflict.html',root.parent/'merge-conflict-updated.html']:path.write_text(html)
print('Built fully offline HTML, including 21 embedded logo images.')
