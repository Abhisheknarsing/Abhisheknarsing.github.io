from pathlib import Path
import re,ast,json,base64
root=Path(__file__).parent
original=(Path('/Users/abhishek/Desktop/Game2/merge-conflict/dist/questions.js')).read_text()
# Retain only the two relaxed original categories, as literal data.
objects=[]
for line in original.splitlines():
 if line.startswith("{type:'emoji'") or line.startswith("{type:'riddle'"):objects.append(line.rstrip(','))
source=Path('/Users/abhishek/Desktop/3/ship-it-friday.html').read_text()
cards=[]
for word,banned in re.findall(r"\{ word: ('(?:\\.|[^'])*'), banned: (\[[^\]]+\]) \}",source):cards.append({'word':ast.literal_eval(word),'banned':ast.literal_eval(banned)})
extra=[('Coffee break',['Drink','Cup','Caffeine','Office','Tea']),('Friday',['Weekend','Day','Saturday','Thursday','Work']),('Password',['Secret','Login','Characters','Account','Security']),('Laptop',['Computer','Portable','Screen','Keyboard','MacBook']),('Wi-Fi',['Wireless','Internet','Router','Network','Connect']),('Keyboard',['Type','Keys','Mouse','Letters','Computer']),('Screenshot',['Image','Screen','Capture','Picture','Photo']),('Headphones',['Music','Ears','Audio','Listen','Sound']),('Video call',['Meeting','Camera','Zoom','Teams','Microphone']),('Mute',['Sound','Microphone','Quiet','Audio','Speak']),('Work from home',['Remote','Office','House','Commute','Pajamas']),('Notification',['Alert','Bell','Message','Popup','Ping']),('Emoji',['Face','Smile','Picture','Chat','Reaction']),('Browser',['Chrome','Firefox','Internet','Web','Tab']),('Bookmark',['Save','Page','Browser','Link','Favorite']),('Recycle bin',['Delete','Trash','Restore','File','Empty']),('Copy paste',['Clipboard','Duplicate','Text','Ctrl','Shortcut']),('Autocorrect',['Spelling','Phone','Mistake','Type','Correct']),('Airplane mode',['Flight','Phone','Signal','Wireless','Offline']),('Power bank',['Battery','Charge','Portable','Phone','USB']),('QR code',['Scan','Square','Camera','Black','White']),('Bluetooth',['Wireless','Connect','Speaker','Pair','Headphones']),('Loading screen',['Wait','Progress','Bar','Spinner','Buffer']),('Undo',['Reverse','Mistake','Ctrl','Back','Action']),('Refresh',['Reload','Page','Browser','Update','F5']),('Out of office',['Email','Vacation','Away','Reply','Holiday']),('Lunch break',['Food','Eat','Noon','Hungry','Office']),('Brainstorm',['Ideas','Think','Meeting','Creative','Discuss']),('Whiteboard',['Marker','Draw','Erase','Meeting','Write']),('Presentation',['Slides','PowerPoint','Talk','Audience','Screen'])]
cards += [{'word':w,'banned':b} for w,b in extra]
# Carry over additional emoji cards, avoiding duplicate answers.
skip={'Docker','Rubber duck debugging','Spaghetti code','Cookie','Firewall'}
for clue,hint,answer in re.findall(r"\{ q: ('(?:\\.|[^'])*'), hint: ('(?:\\.|[^'])*'), answer: ('(?:\\.|[^'])*') \}",source):
 a=ast.literal_eval(answer)
 if a in skip:continue
 objects.append(json.dumps({'type':'emoji','prompt':'Decode this developer phrase.','clue':ast.literal_eval(clue),'hint':ast.literal_eval(hint),'answer':a,'explain':'Accept an equivalent phrase at the host’s discretion.'},ensure_ascii=False))
brands=[('carrefour','Carrefour'),('polestar','Polestar'),('reebok','Reebok'),('maserati','Maserati'),('infiniti','Infiniti'),('skoda','Škoda'),('citroen','Citroën'),('opel','Opel'),('vauxhall','Vauxhall'),('atari','Atari'),('ubisoft','Ubisoft'),('razer','Razer'),('steelseries','SteelSeries'),('corsair','Corsair'),('logitechg','Logitech G'),('beats','Beats'),('auchan','Auchan'),('singaporeairlines','Singapore Airlines'),('turkishairlines','Turkish Airlines'),('aircanada','Air Canada'),('motorola','Motorola')]
for slug,name in brands:
 svg=(root/'dist/assets'/f'{slug}.svg').read_text()
 svg=re.sub(r'<title>.*?</title>','',svg)
 uri='data:image/svg+xml;base64,'+base64.b64encode(svg.encode()).decode()
 objects.append(json.dumps({'type':'logo','prompt':'Which brand owns this symbol?','image':uri,'hint':f'The brand name starts with “{name[0]}”.','answer':name,'explain':'Recognized it without the brand name? That earns 100 points.'},ensure_ascii=False))
(root/'dist/questions.js').write_text('// Logo symbols: Simple Icons (https://simpleicons.org), embedded for offline use.\nconst QUESTIONS = [\n'+',\n'.join(objects)+'\n];\nconst TABOO_CARDS = '+json.dumps(cards,ensure_ascii=False)+';\n')
(root/'CREDITS.md').write_text('# Asset credits\n\nLogo symbols sourced from Simple Icons: https://simpleicons.org and https://github.com/simple-icons/simple-icons. Downloaded from the simple-icons npm distribution via jsDelivr on 16 October 2026. Brand marks belong to their respective owners. The quiz uses monochrome symbol variants for recognition.\n\nDev Taboo’s original 22 cards and additional emoji puzzles were adapted from the supplied ship-it-friday.html. 30 additional Taboo cards were added.\n')
print(f'{len(objects)} puzzles, {len(cards)} Taboo cards, {len(brands)} embedded logos.')
