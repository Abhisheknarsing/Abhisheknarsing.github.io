const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const context=vm.createContext({console,localStorage:{getItem:()=>null,setItem:()=>{}},document:{addEventListener:()=>{}},window:{addEventListener:()=>{},scrollTo:()=>{}},setInterval,clearInterval,setTimeout,clearTimeout,matchMedia:()=>({matches:true})});
vm.runInContext(fs.readFileSync('dist/questions.js','utf8')+'\n'+fs.readFileSync('dist/app.js','utf8').replace(/render\(\);\s*$/,''),context);
vm.runInContext(`render=()=>{};toast=()=>{};
for(const mode of Object.keys(MODES)) for(const rounds of [6,12]) {
 config={teams:['A','B','C','D','E','F'],mode,rounds,seconds:30};start();
 if(game.deck.length!==rounds)throw Error('Wrong deck length');
 if(new Set(game.deck.map(q=>q.prompt+'|'+(q.clue||q.code||'')+'|'+q.type)).size!==rounds)throw Error('Repeated puzzle');
 if(mode==='mix' && ['emoji','riddle','bug'].some(t=>game.deck.filter(q=>q.type===t).length!==rounds/3))throw Error('Unbalanced mix');
 reveal();award(0);if(game.scores[0]!==100)throw Error('Award failed');
 award(1);if(game.scores[0]!==0||game.scores[1]!==100)throw Error('Award move failed');
 award(1);if(game.scores[1]!==0)throw Error('Undo failed');
 for(let i=0;i<rounds;i++)next();
 if(!game.finished||screen!=='results')throw Error('Game did not finish');
}
if(esc('<img onerror="x">').includes('<'))throw Error('HTML escaping failed');
`,context);
assert.equal(vm.runInContext('QUESTIONS.length',context),36);
console.log('PASS: 8 deck configurations, no repeats, balanced mix, six-team scoring, award correction, undo, game completion, HTML escaping.');
